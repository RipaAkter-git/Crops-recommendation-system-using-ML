from django.shortcuts import render,redirect
import pickle as pk
from sklearn.linear_model import LinearRegression
import numpy as np
import pandas as pd
# Create your views here.
def index(request):
    if request.method=="POST":
        N=float(request.POST.get("N"))
        P=float(request.POST.get("P"))     
        K=float(request.POST.get("K"))    
        temp=float(request.POST.get("temp"))
        hum=float(request.POST.get("hum"))
        pH=float(request.POST.get("pH"))
        rain=float(request.POST.get("rain"))
        with open('index/Model_pickle.sav','rb') as file:
            Model=pk.load(file)
        result=str(Model.predict([[N,P,K,temp,hum,pH,rain]])[0])
        Prediction=Model.predict_proba([[N,P,K,temp,hum,pH,rain]])
        Prob_table=pd.concat([pd.DataFrame(Model.classes_,columns=['Category']),pd.DataFrame(np.reshape(Prediction,(22,1)),columns=['Probability'])],axis=1)
        Prob_table['Probability']=[float("{:.4f}".format(i)) for i in Prob_table['Probability']]
        return render(request,'index/result.html',{
            'result':result,
            'Prob_table':Prob_table
        })
    return render(request,'index/index.html')